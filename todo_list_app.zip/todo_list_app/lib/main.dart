import 'package:flutter/material.dart';
import 'package:todo_list_app/database/todo_database.dart';
import 'package:todo_list_app/model/todo.dart';
import 'package:todo_list_app/screens/detail_screen.dart';
import 'package:todo_list_app/screens/form_screen.dart';
import 'package:todo_list_app/utils/helper.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: .fromSeed(seedColor: Colors.deepPurple),
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {

  late TodoDatabase todoDatabase;
  List<Todo> listTodo = [];
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    todoDatabase = TodoDatabase();
    getListTodo();
  }

  void getListTodo() async {
    isLoading = true;
    await todoDatabase.getAllTodo()
        .then((value){
          listTodo = value;
        })
        .catchError((error){
          Helper.showSnackbar(context, "Error saat menampilkan data $error");
        })
        .whenComplete((){
          setState(() {
            isLoading = false;
          });
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text("Todo List"),
      ),
      body: Center(
        child: isLoading
            ? CircularProgressIndicator()
            : listTodo.isEmpty
              ? Text("Belum ada data")
              : ListView.builder(
                  itemCount: listTodo.length,
                  itemBuilder: (context, index){
                    final todo = listTodo[index];
                    return cardTodo(todo);
                  },
                ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: (){
          Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => FormScreen())
          ).then((value){
            if (value == Helper.NEED_REFRESH){
              getListTodo();
            }
          });
        },
        tooltip: 'Increment',
        child: const Icon(Icons.add),
      ),
    );
  }

  /// tampilkan card/kotak data
  Widget cardTodo(Todo todo){
    return GestureDetector(
      onTap: (){
        Navigator.push(
            context, 
            MaterialPageRoute(builder: (context) => DetailScreen(id: todo.id ?? 0))
        ).then((value){
          if (value == Helper.NEED_REFRESH){
            getListTodo();
          }
        });
      },
      child: Card(
        elevation: 4,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        child: Padding(
          padding: EdgeInsets.all(8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Flexible(
                    child: Text(
                      todo.title,
                      style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                    ),
                  ),
                  todo.isCompleted
                      ? Icon(Icons.check_circle, color: Colors.green)
                      : Icon(
                        Icons.do_not_disturb_on_rounded,
                        color: Colors.orange,
                      ),
                ],
              ),
              Text("Kategori: ${todo.category}", style: TextStyle(fontSize: 20)),
              Text("Prioritas: ${todo.priority}", style: TextStyle(fontSize: 20)),
              Text("Hari: ${todo.days}", style: TextStyle(fontSize: 20)),
            ],
          ),
        ),
      ),
    );
  }


}
